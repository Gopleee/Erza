					[ 2CEIT509 MOBILE APPLICATION DEVELOPMENT] 

				       Department of Computer Engineering/Information Technology 
 
							

   Submitted By: Dhruv M Shah	
   Enrollment number: 19012011075 
   MAD-5   5th Sem
 
							   Assignment-2

							>>>Abstract<<<

          ERZA
  Sci-Fi & Anime Player

#This app is created by concepts taught in Class and Lab and from snippets of code taken from the internet.

#Almost all of the design part is done solely by me whereas the coding part is made either by myself or by taking snippets of    code from online platforms.


							>>>Procedure<<<

#Erza is a one of a kind player made by me to play songs on your Android device.

#It uses features like listview, animation, service, broadcastreceiver, intent, database,sharedpreference and inbuilt android library modules to play songs found in your android device.

#Animation:-  Animated logo shows up when user runs the application. This was made using the concepts taught in lab and class.
 
#ListView:- This is used to show the songs the found in the device so the user can play the song of his/her liking.

#Intent:- Intent is used to move from one activity to another as well as for other features like forming playlist and Favourite songs.

#Services:- Services is used according to the concept taught in the recorded lecture by Prof. Hiten and also from online Youtube videos. By using this feature user can play songs even if the activity is minimized.

#Broadcastreceiver:- This is used to show the song that is being played in notification bar of the device. Further I have developed this so that user can play/pause the song as well as change the song from the notification. 	User can also put the song in Favourite folder of the app.

#Sharedpreference:- This concept was used for storing favourites data.

#Binding:- This was a new concept for me which I learnt from the web. Binding was used so that design part of the application i.e. xml files could work together with the coding files i.e. kt files. Unique ID was given to views to be used in every kt files. I also wanted to make different themes for the app using binding but was unable to do so.

#Adapter:- This too was a new concept i tried to implement in my application which was learnt through Youtube. Snippets of code was taken from the web which were then implemented in my application. An Adapter object acts as a bridge between view and the data. This was used to show data of each song in the application.

#Companion Object:- This concept was taught in lab according to which we can save data in form of string by making it 1 file. Then this file is called in different activities for viewing of data. Made according to pr-7.


							>>>Features<<<

#Sort Feature:- User can sort songs according to 1. Recently Added  2. Song Title  3. File Size
The code of this feature was directly taken from the web and modified and implemented by me.

#Shuffle Feature:- User can shuffle play their songs. 
The code of this feature was directly taken from the web and modified and implemented by me.

#Timer:- Timer feature is added in which the user can program the application to stop the music after mentioned time period.
(This feature is a bit buggy and not implemented to perfection)
The code of this feature was directly taken from the web and modified and implemented by me.

#Share Songs:- User can share their desired song directly from the application.
(This feature works only in Whatsapp.)
The code of this feature was directly taken from the web and modified and implemented by me.


							>>>Ending Note<<<

This app was individually created by me. 
Snippets of code and extra features were added into the application using the help of Internet.